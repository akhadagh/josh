package com.example.healthtrack.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Represents a single daily health record saved by the user.
 */
@Entity(tableName = "health_records")
public class HealthRecord {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String patientName;
    public String temperature;
    public String date;

    public HealthRecord(String patientName, String temperature, String date) {
        this.patientName = patientName;
        this.temperature = temperature;
        this.date = date;
    }
}
