package com.example.healthtrack.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.healthtrack.model.HealthRecord;

import java.util.List;

@Dao
public interface HealthRecordDao {

    @Insert
    void insert(HealthRecord record);

    // Newest records first
    @Query("SELECT * FROM health_records ORDER BY id DESC")
    List<HealthRecord> getAllRecords();
}
