package com.example.healthtrack.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.healthtrack.util.NotificationHelper;

/**
 * Fired by AlarmManager at the scheduled reminder time.
 * Shows a notification telling the user to take their medication.
 */
public class ReminderReceiver extends BroadcastReceiver {

    public static final String EXTRA_MEDICINE_NAME = "medicineName";

    @Override
    public void onReceive(Context context, Intent intent) {
        String medicineName = intent.getStringExtra(EXTRA_MEDICINE_NAME);
        if (medicineName == null) {
            medicineName = "your medication";
        }
        NotificationHelper.showNotification(context, medicineName);
    }
}
