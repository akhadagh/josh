package com.example.healthtrack;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthtrack.databinding.ActivitySetReminderBinding;
import com.example.healthtrack.receiver.ReminderReceiver;

import java.util.Calendar;
import java.util.Locale;

/**
 * Set Medication Reminder screen - lets the user pick a medicine name and a time,
 * then schedules a one-time exact alarm via AlarmManager. When it fires,
 * ReminderReceiver (a BroadcastReceiver) shows a notification.
 */
public class SetReminderActivity extends AppCompatActivity {

    private ActivitySetReminderBinding binding;
    private int hour = -1;
    private int minute = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySetReminderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.etTime.setFocusable(false);
        binding.etTime.setOnClickListener(v -> showTimePicker());

        binding.btnSetAlarm.setOnClickListener(v -> scheduleReminder());
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();
        new TimePickerDialog(this, (view, selectedHour, selectedMinute) -> {
            hour = selectedHour;
            minute = selectedMinute;
            binding.etTime.setText(String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute));
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show();
    }

    private void scheduleReminder() {
        String medicineName = binding.etMedicineName.getText().toString().trim();

        // --- Validation ---
        if (medicineName.isEmpty()) {
            binding.etMedicineName.setError("Medicine name is required");
            binding.etMedicineName.requestFocus();
            return;
        }
        if (hour == -1) {
            Toast.makeText(this, "Please select a reminder time", Toast.LENGTH_SHORT).show();
            return;
        }

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (alarmManager == null) {
            Toast.makeText(this, "Unable to access the alarm service", Toast.LENGTH_SHORT).show();
            return;
        }

        // Android 12+ requires the user to grant exact-alarm permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            Toast.makeText(this, "Please allow exact alarms for Health Track", Toast.LENGTH_LONG).show();
            startActivity(new Intent(
                    Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName())
            ));
            return;
        }

        Calendar triggerTime = Calendar.getInstance();
        triggerTime.set(Calendar.HOUR_OF_DAY, hour);
        triggerTime.set(Calendar.MINUTE, minute);
        triggerTime.set(Calendar.SECOND, 0);
        // If the chosen time has already passed today, schedule for tomorrow
        if (triggerTime.before(Calendar.getInstance())) {
            triggerTime.add(Calendar.DAY_OF_YEAR, 1);
        }

        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra(ReminderReceiver.EXTRA_MEDICINE_NAME, medicineName);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                medicineName.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTime.getTimeInMillis(),
                pendingIntent
        );

        Toast.makeText(
                this,
                "Reminder set for " + medicineName + " at " + binding.etTime.getText(),
                Toast.LENGTH_LONG
        ).show();
        finish();
    }
}
