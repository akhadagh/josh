package com.example.healthtrack;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthtrack.databinding.ActivityAddRecordBinding;
import com.example.healthtrack.db.AppDatabase;
import com.example.healthtrack.model.HealthRecord;
import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;
import java.util.Locale;

/**
 * Add Health Record screen - captures Patient Name, Temperature and Date,
 * validates the input, then saves it to the Room database.
 */
public class AddRecordActivity extends AppCompatActivity {

    private ActivityAddRecordBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddRecordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.etDate.setFocusable(false);
        binding.etDate.setOnClickListener(v -> showDatePicker());

        binding.btnSave.setOnClickListener(v -> saveRecord());
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            String formatted = String.format(
                    Locale.getDefault(), "%02d/%02d/%04d", selectedDay, selectedMonth + 1, selectedYear
            );
            binding.etDate.setText(formatted);
        }, year, month, day).show();
    }

    private void saveRecord() {
        String name = binding.etPatientName.getText().toString().trim();
        String temp = binding.etTemperature.getText().toString().trim();
        String date = binding.etDate.getText().toString().trim();

        // --- Validation ---
        if (name.isEmpty()) {
            binding.etPatientName.setError("Patient name is required");
            binding.etPatientName.requestFocus();
            return;
        }

        if (temp.isEmpty()) {
            binding.etTemperature.setError("Temperature is required");
            binding.etTemperature.requestFocus();
            return;
        }

        double tempValue;
        try {
            tempValue = Double.parseDouble(temp);
        } catch (NumberFormatException e) {
            binding.etTemperature.setError("Enter a valid number");
            binding.etTemperature.requestFocus();
            return;
        }

        if (tempValue < 30.0 || tempValue > 45.0) {
            binding.etTemperature.setError("Enter a realistic temperature (30-45 °C)");
            binding.etTemperature.requestFocus();
            return;
        }

        if (date.isEmpty()) {
            Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show();
            return;
        }

        // --- Save to Room (off the main thread) ---
        HealthRecord record = new HealthRecord(name, temp, date);

        AppDatabase.databaseExecutor.execute(() -> {
            AppDatabase.getDatabase(getApplicationContext()).healthRecordDao().insert(record);
            runOnUiThread(() -> {
                Snackbar.make(binding.getRoot(), "Record saved successfully", Snackbar.LENGTH_SHORT).show();
                clearForm();
            });
        });
    }

    private void clearForm() {
        binding.etPatientName.getText().clear();
        binding.etTemperature.getText().clear();
        binding.etDate.getText().clear();
    }
}
