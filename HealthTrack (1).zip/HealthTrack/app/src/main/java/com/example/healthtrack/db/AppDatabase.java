package com.example.healthtrack.db;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.healthtrack.model.HealthRecord;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {HealthRecord.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract HealthRecordDao healthRecordDao();

    // Room forbids database work on the main thread, so all callers run
    // their queries through this shared background executor.
    public static final ExecutorService databaseExecutor = Executors.newFixedThreadPool(2);

    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDatabase(@NonNull final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "health_track_db"
                    ).build();
                }
            }
        }
        return INSTANCE;
    }
}
