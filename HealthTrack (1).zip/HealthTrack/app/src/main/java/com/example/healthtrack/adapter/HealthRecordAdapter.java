package com.example.healthtrack.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthtrack.databinding.ItemHealthRecordBinding;
import com.example.healthtrack.model.HealthRecord;

import java.util.ArrayList;
import java.util.List;

public class HealthRecordAdapter extends RecyclerView.Adapter<HealthRecordAdapter.RecordViewHolder> {

    private List<HealthRecord> records = new ArrayList<>();

    public static class RecordViewHolder extends RecyclerView.ViewHolder {
        final ItemHealthRecordBinding binding;

        RecordViewHolder(ItemHealthRecordBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @NonNull
    @Override
    public RecordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemHealthRecordBinding binding = ItemHealthRecordBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false
        );
        return new RecordViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecordViewHolder holder, int position) {
        HealthRecord record = records.get(position);
        holder.binding.tvPatientName.setText(record.patientName);
        holder.binding.tvTemperature.setText("Temperature: " + record.temperature + " °C");
        holder.binding.tvDate.setText("Date: " + record.date);
    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    public void updateData(List<HealthRecord> newRecords) {
        this.records = newRecords;
        notifyDataSetChanged();
    }
}
