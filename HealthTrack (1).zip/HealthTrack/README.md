# Health Track (Prototype)

A prototype Android app (Java) for a local health organization. Users can record
daily health information, view saved records, and set medication reminders.

## What's included

- **Home Screen** — buttons for Add Health Record, View Records, Set Medication Reminder
- **Add Health Record** — Patient Name, Temperature, Date (via DatePicker), validated
  before saving to a Room database
- **View Records** — all saved records shown in a RecyclerView, with a search bar to
  filter by patient name (the "extra enhancement")
- **Medication Reminders** — pick a medicine name + time (TimePicker); AlarmManager
  schedules an exact alarm; a BroadcastReceiver (`ReminderReceiver`) fires at that time
  and shows a notification via NotificationManager
- Validation throughout, with Toast / Snackbar feedback
- Simple adaptive launcher icon (medical-cross theme)
- DayNight theme (Material Components), so dark mode follows the system setting

## Project structure

```
HealthTrack/
├── settings.gradle
├── build.gradle                  (project-level)
├── gradle.properties
└── app/
    ├── build.gradle               (module-level, Room uses annotationProcessor for Java)
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/healthtrack/
        │   ├── MainActivity.java            (Home screen)
        │   ├── AddRecordActivity.java        (Add record + validation + Room insert)
        │   ├── ViewRecordsActivity.java       (RecyclerView + search)
        │   ├── SetReminderActivity.java       (AlarmManager scheduling)
        │   ├── model/HealthRecord.java        (Room @Entity)
        │   ├── db/HealthRecordDao.java        (Room @Dao)
        │   ├── db/AppDatabase.java            (Room database singleton + ExecutorService)
        │   ├── adapter/HealthRecordAdapter.java
        │   ├── receiver/ReminderReceiver.java  (BroadcastReceiver)
        │   └── util/NotificationHelper.java    (NotificationManager wrapper)
        └── res/
            ├── layout/   (4 activity layouts + 1 list item layout)
            ├── values/   (strings, colors, themes)
            ├── drawable/ (launcher icon vectors)
            └── mipmap-anydpi-v26/ (adaptive launcher icon)
```

## No Gradle wrapper included

As requested, the `gradlew` / `gradlew.bat` scripts and the `gradle/wrapper/` folder
are **not** included — only the actual project source. To get it running:

1. Unzip the project and open the `HealthTrack` folder in Android Studio
   (File → Open → select the `HealthTrack` folder).
2. Android Studio will offer to generate the missing Gradle wrapper automatically,
   or run `gradle wrapper` yourself from a terminal inside the project folder if you
   have Gradle installed locally.
3. Let Gradle sync — it will download the dependencies listed in `app/build.gradle`
   (AndroidX, Material Components, Room, etc.) via Google's / Maven Central's
   repositories, which are already declared in the root `build.gradle`.
4. Run on an emulator or device with API 23+ (Android 6.0+).

## Java-specific notes

- No Kotlin plugin or `kapt` — Room's annotation processor runs through plain
  `annotationProcessor` in `app/build.gradle`.
- ViewBinding is still used (it works the same way in Java as in Kotlin) so there's
  no manual `findViewById` boilerplate.
- Room forbids database calls on the main thread, so there's a small shared
  `ExecutorService` (`AppDatabase.databaseExecutor`) used for inserts/queries, with
  `runOnUiThread(...)` to hop back to the UI thread when updating views — this
  replaces what coroutines would normally do in Kotlin.

## Notes for whoever picks this up next

- Minimum SDK is 23, target/compile SDK is 34 — adjust in `app/build.gradle` if needed.
- On Android 12+ the user must grant "exact alarm" permission the first time they try
  to set a reminder; `SetReminderActivity` already checks for this and sends the user
  to the system settings screen if it isn't granted yet.
- On Android 13+ a notification permission prompt appears the first time `MainActivity`
  is opened (required for the app to be allowed to show reminder notifications at all).
- Temperature is validated as a number between 30–45 °C as a basic sanity check —
  adjust the range in `AddRecordActivity.saveRecord()` if the organization wants
  Fahrenheit or a different range.
- This is a prototype: no login/auth, no editing/deleting of records, single
  reminder at a time replaces itself if the same medicine name is reused (uses the
  medicine name's hash as the alarm/notification ID). These would be natural next
  steps for a fuller version.
