package com.example.healthtrack;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.healthtrack.databinding.ActivityMainBinding;

/**
 * Home Screen - entry point with navigation to the three core features.
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        requestNotificationPermissionIfNeeded();

        binding.btnAddRecord.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddRecordActivity.class)));

        binding.btnViewRecords.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ViewRecordsActivity.class)));

        binding.btnSetReminder.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, SetReminderActivity.class)));
    }

    // Android 13+ requires runtime permission before notifications can be shown
    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100
                );
            }
        }
    }
}
