package com.example.healthtrack;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.healthtrack.adapter.HealthRecordAdapter;
import com.example.healthtrack.databinding.ActivityViewRecordsBinding;
import com.example.healthtrack.db.AppDatabase;
import com.example.healthtrack.model.HealthRecord;

import java.util.ArrayList;
import java.util.List;

/**
 * View Records screen - displays every saved health record in a RecyclerView.
 * Enhancement: a SearchView lets the user filter records by patient name.
 */
public class ViewRecordsActivity extends AppCompatActivity {

    private ActivityViewRecordsBinding binding;
    private HealthRecordAdapter adapter;
    private List<HealthRecord> allRecords = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewRecordsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        adapter = new HealthRecordAdapter();
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerView.setAdapter(adapter);

        binding.searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterRecords(newText);
                return true;
            }
        });

        loadRecords();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadRecords(); // refresh in case a new record was just added
    }

    private void loadRecords() {
        AppDatabase.databaseExecutor.execute(() -> {
            List<HealthRecord> records =
                    AppDatabase.getDatabase(getApplicationContext()).healthRecordDao().getAllRecords();
            runOnUiThread(() -> {
                allRecords = records;
                adapter.updateData(allRecords);
                updateEmptyState(allRecords.isEmpty());
            });
        });
    }

    private void filterRecords(String query) {
        List<HealthRecord> filtered = new ArrayList<>();
        if (query == null || query.trim().isEmpty()) {
            filtered.addAll(allRecords);
        } else {
            String lowerQuery = query.toLowerCase();
            for (HealthRecord record : allRecords) {
                if (record.patientName.toLowerCase().contains(lowerQuery)) {
                    filtered.add(record);
                }
            }
        }
        adapter.updateData(filtered);
        updateEmptyState(filtered.isEmpty());
    }

    private void updateEmptyState(boolean isEmpty) {
        binding.tvEmpty.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        binding.recyclerView.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
    }
}
